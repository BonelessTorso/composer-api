<?php
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\Factory\AppFactory;

require __DIR__ . '/../vendor/autoload.php';

require __DIR__ . '/../includes/DbOperations.php';

$app = AppFactory::create();

$container = $app->getContainer();
$container['upload_directory'] = __DIR__ . '/../uploads/';

$app->setBasePath("/Sahihisha_Kenya_API/public");

$app->add(new Tuupola\Middleware\HttpBasicAuthentication([
    "users" => [
        "williefredo" => "mwangi",
    ]
]));

$app->post('/createuser', function(Request $request, Response $response){

    if(!haveEmptyParameters(array('email', 'phone', 'username', 'password'), $request, $response)){

        $request_data = $request->getParsedBody(); 

        $email = $request_data['email'];
        $phone = $request_data['phone'];
        $username = $request_data['username'];
        $password = $request_data['password']; 

        $hash_password = password_hash($password, PASSWORD_DEFAULT);

        $db = new DbOperations; 

        $result = $db->createUser($email, $phone, $username, $hash_password);
        
        if($result == USER_CREATED){

            $message = array(); 
            $message['error'] = false; 
            $message['message'] = 'User created successfully';

            $response->getBody()->write(json_encode($message));

            return $response
                        ->withHeader('Content-type', 'application/json')
                        ->withStatus(201);

        }else if($result == USER_FAILURE){

            $message = array(); 
            $message['error'] = true; 
            $message['message'] = 'Some error occurred';

            $response->getBody()->write(json_encode($message));

            return $response
                        ->withHeader('Content-type', 'application/json')
                        ->withStatus(422);    

        }else if($result == USER_EXISTS){
            $message = array(); 
            $message['error'] = true; 
            $message['message'] = 'User Already Exists';

            $response->getBody()->write(json_encode($message));

            return $response
                        ->withHeader('Content-type', 'application/json')
                        ->withStatus(422);    
        }
    }
    return $response
        ->withHeader('Content-type', 'application/json')
        ->withStatus(422);    
});

$app->post('/userlogin', function(Request $request, Response $response){

    if(!haveEmptyParameters(array('username', 'password'), $request, $response)){
        $request_data = $request->getParsedBody(); 

        $username = $request_data['username'];
        $password = $request_data['password'];
        
        $db = new DbOperations; 

        $result = $db->userLogin($username, $password);

        if($result == USER_AUTHENTICATED){
            
            $user = $db->getUserByUsername($username);
            $response_data = array();

            $response_data['error']=false; 
            $response_data['message'] = 'Login Successful';
            $response_data['user']=$user; 

            $response->getBody()->write(json_encode($response_data));

            return $response
                ->withHeader('Content-type', 'application/json')
                ->withStatus(200);    

        }else if($result == USER_NOT_FOUND){
            $response_data = array();

            $response_data['error']=true; 
            $response_data['message'] = 'User not exist';

            $response->getBody()->write(json_encode($response_data));

            return $response
                ->withHeader('Content-type', 'application/json')
                ->withStatus(200);    

        }else if($result == USER_PASSWORD_DO_NOT_MATCH){
            $response_data = array();

            $response_data['error']=true; 
            $response_data['message'] = 'Invalid credential';

            $response->getBody()->write(json_encode($response_data));

            return $response
                ->withHeader('Content-type', 'application/json')
                ->withStatus(200);  
        }
    }

    return $response
        ->withHeader('Content-type', 'application/json')
        ->withStatus(422);    
});

$app->get('/allusers', function(Request $request, Response $response){

    $db = new DbOperations; 

    $users = $db->getAllUsers();

    $response_data = array();

    $response_data['error'] = false; 
    $response_data['users'] = $users; 

    $response->getBody()->write(json_encode($response_data));

    return $response
    ->withHeader('Content-type', 'application/json')
    ->withStatus(200);  

});

$app->post('/updateuser/{id}', function(Request $request, Response $response, array $args){

    $id = $args['id'];

    if(!haveEmptyParameters(array('email','phone','username','id'), $request, $response)){

        $request_data = $request->getParsedBody(); 
        $email = $request_data['email'];
        $phone = $request_data['phone'];
        $username = $request_data['username'];
        $id = $request_data['id'];  
     

        $db = new DbOperations; 

        if($db->updateUser($email, $phone, $username, $id)){
            $response_data = array(); 
            $response_data['error'] = false; 
            $response_data['message'] = 'User Updated Successfully';
            $user = $db->getUserByUsername($username);
            $response_data['user'] = $user; 

            $response->getBody()->write(json_encode($response_data));

            return $response
            ->withHeader('Content-type', 'application/json')
            ->withStatus(200);  
        
        }else{
            $response_data = array(); 
            $response_data['error'] = true; 
            $response_data['message'] = 'Please try again later';
            $user = $db->getUserByUsername($username);
            $response_data['user'] = $user; 

            $response->getBody()->write(json_encode($response_data));

            return $response
            ->withHeader('Content-type', 'application/json')
            ->withStatus(200);  
              
        }

    }
    
    return $response
    ->withHeader('Content-type', 'application/json')
    ->withStatus(200);  

});

$app->post('/updatepassword', function(Request $request, Response $response){

    if(!haveEmptyParameters(array('currentpassword', 'newpassword', 'username'), $request, $response)){
        
        $request_data = $request->getParsedBody(); 

        $currentpassword = $request_data['currentpassword'];
        $newpassword = $request_data['newpassword'];
        $username = $request_data['username']; 

        $db = new DbOperations; 

        $result = $db->updatePassword($currentpassword, $newpassword, $username);

        if($result == PASSWORD_CHANGED){
            $response_data = array(); 
            $response_data['error'] = false;
            $response_data['message'] = 'Password Changed';
            $response->getBody()->write(json_encode($response_data));
            return $response->withHeader('Content-type', 'application/json')
                            ->withStatus(200);

        }else if($result == PASSWORD_DO_NOT_MATCH){
            $response_data = array(); 
            $response_data['error'] = true;
            $response_data['message'] = 'You have given wrong password';
            $response->getBody()->write(json_encode($response_data));
            return $response->withHeader('Content-type', 'application/json')
                            ->withStatus(200);
        }else if($result == PASSWORD_NOT_CHANGED){
            $response_data = array(); 
            $response_data['error'] = true;
            $response_data['message'] = 'Some error occurred';
            $response->getBody()->write(json_encode($response_data));
            return $response->withHeader('Content-type', 'application/json')
                            ->withStatus(200);
        }
    }

    return $response
        ->withHeader('Content-type', 'application/json')
        ->withStatus(422);  
});

$app->delete('/deleteuser/{id}', function(Request $request, Response $response, array $args){
    $id = $args['id'];

    $db = new DbOperations; 

    $response_data = array();

    if($db->deleteUser($id)){
        $response_data['error'] = false; 
        $response_data['message'] = 'User has been deleted';    
    }else{
        $response_data['error'] = true; 
        $response_data['message'] = 'Plase try again later';
    }

    $response->getBody()->write(json_encode($response_data));

    return $response
    ->withHeader('Content-type', 'application/json')
    ->withStatus(200);
});

function haveEmptyParameters($required_params, $request, $response){
    $error = false; 
    $error_params = '';
    $request_params = $request->getParsedBody(); 

    foreach($required_params as $param){
        if(!isset($request_params[$param]) || strlen($request_params[$param])<=0){
            $error = true; 
            $error_params .= $param . ', ';
        }
    }

    if($error){
        $error_detail = array();
        $error_detail['error'] = true; 
        $error_detail['message'] = 'Required parameters ' . substr($error_params, 0, -2) . ' are missing or empty';
        $response->getBody()->write(json_encode($error_detail));

    }
    return $error; 
}

$app->get('/testsbyteacher/{test_code}', function(Request $request, Response $response){

    $test_code = $args['test_code'];

    $db = new DbOperations; 

    $users = $db->getTestsByUsername();

    $response_data = array();

    $response_data['error'] = false; 
    $response_data['users'] = $users; 

    $response->getBody()->write(json_encode($response_data));

    return $response
    ->withHeader('Content-type', 'application/json')
    ->withStatus(200);  

});

$app->post('/addtestdetails', function(Request $request, Response $response){

    if(!haveEmptyParameters(array('test_code', 'class', 'subject', 'time'), $request, $response)){

        $request_data = $request->getParsedBody(); 

        $test_code = $request_data['test_code'];
        $class = $request_data['class'];
        $subject = $request_data['subject'];
        $time = $request_data['time']; 

        $db = new DbOperations; 

        $result = $db->insertPreliminaries($test_code, $class, $subject, $time);
        
        if($result == TEST_DETAILS_ADDED){

            $message = array(); 
            $message['error'] = false; 
            $message['message'] = 'Test details added successfully';

            $response->getBody()->write(json_encode($message));

            return $response
                        ->withHeader('Content-type', 'application/json')
                        ->withStatus(201);

        }else if($result == TEST_DETAILS_NOT_ADDED){

            $message = array(); 
            $message['error'] = true; 
            $message['message'] = 'Some error occurred';

            $response->getBody()->write(json_encode($message));

            return $response
                        ->withHeader('Content-type', 'application/json')
                        ->withStatus(422);
        }   

    }
    return $response
        ->withHeader('Content-type', 'application/json')
        ->withStatus(422);    
});

$app->post('/addquestion', function(Request $request, Response $response){

    if(!haveEmptyParameters(array('test_code', 'question', 'answer_one', 'answer_two', 'answer_three', 'answer_four', 'answer'), $request, $response)){

        $request_data = $request->getParsedBody(); 

        $test_code = $request_data['test_code'];
        $question = $request_data['question'];
        $answer_one = $request_data['answer_one'];
        $answer_two = $request_data['answer_two'];
        $answer_three = $request_data['answer_three'];
        $answer_four = $request_data['answer_four'];
        $answer = $request_data['answer']; 

        $db = new DbOperations; 

        $result = $db->insertQuestions($test_code, $question, $answer_one, $answer_two, $answer_three, $answer_four, $answer);
        
        if($result == QUESTION_ADDED){

            $message = array(); 
            $message['error'] = false; 
            $message['message'] = 'Test added successfully';

            $response->getBody()->write(json_encode($message));

            return $response
                        ->withHeader('Content-type', 'application/json')
                        ->withStatus(201);

        }else if($result == QUESTION_NOT_ADDED){

            $message = array(); 
            $message['error'] = true; 
            $message['message'] = 'Some error occurred';

            $response->getBody()->write(json_encode($message));

            return $response
                        ->withHeader('Content-type', 'application/json')
                        ->withStatus(422);
        }   

    }
    return $response
        ->withHeader('Content-type', 'application/json')
        ->withStatus(422);    
});

$app->post('/uploadfile', function (Request $request, Response $response, $args) {

    $uploadedFile = '';
    $filename = '';
    $error = 0;

    $requestbody = $request->getParsedBody();
    $uploadedFiles = $request->getUploadedFiles();
    if ($requestbody['title'] == '') {
        $error = 1;
        return $response->withJson(["status" => "failed", "data" => "Please enter title", "code" => 100]);
    }
    if ($error == 0) {
        if (isset($requestbody) && $requestbody != false) {
            foreach ($requestbody as $field => $value) {
                $sqlUpdateString .= "`$field`='" . addslashes($value) . "', ";
            }
            $sqlUpdateStringFinal = substr($sqlUpdateString, 0, -2);
        }
        if (isset($uploadedFiles['cover']) && $uploadedFiles['cover'] != "") {
            $uploadedFile = $uploadedFiles['cover'];
            if ($uploadedFile != '' && $uploadedFile->getError() === UPLOAD_ERR_OK) {
                $extension = pathinfo($uploadedFile->getClientFilename(), PATHINFO_EXTENSION);
                $filename = sprintf(time() . '_' . '%s.%0.8s', $args["id"], $extension);
                $directory = $this->get('settings')['upload_directory'];
                $uploadedFile->moveTo($directory . DIRECTORY_SEPARATOR . $filename);
                $url = $request->getUri()->getBaseUrl() . "/uploads/" . $filename;
                $data['cover'] = $filename;
                $data['url'] = $url;
            }
        }
        
        return $response->withJson(["status" => "success", "data" => $data], 200);
    }
});

$app->run();
